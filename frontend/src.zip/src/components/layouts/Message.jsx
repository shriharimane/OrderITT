import React from "react";
 
export default function Message({ variant ,children
}){
   // eslint-disable-next-line 
    return <div className={'alert alert-${variant}'}>{children}
    </div>;
}